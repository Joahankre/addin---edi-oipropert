﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FormSelecao
    Inherits System.Windows.Forms.Form

    'Descartar substituições de formulário para limpar a lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Exigido pelo Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'OBSERVAÇÃO: o procedimento a seguir é exigido pelo Windows Form Designer
    'Pode ser modificado usando o Windows Form Designer.  
    'Não o modifique usando o editor de códigos.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.treeModelos = New System.Windows.Forms.TreeView()
        Me.btnSelTodos = New System.Windows.Forms.Button()
        Me.btnDesSelTodos = New System.Windows.Forms.Button()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.btnOK = New System.Windows.Forms.Button()
        Me.Panel1.SuspendLayout()
        Me.SuspendLayout()
        '
        'treeModelos
        '
        Me.treeModelos.CheckBoxes = True
        Me.treeModelos.Dock = System.Windows.Forms.DockStyle.Top
        Me.treeModelos.Location = New System.Drawing.Point(0, 0)
        Me.treeModelos.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.treeModelos.Name = "treeModelos"
        Me.treeModelos.Size = New System.Drawing.Size(800, 678)
        Me.treeModelos.TabIndex = 0
        '
        'btnSelTodos
        '
        Me.btnSelTodos.Location = New System.Drawing.Point(-1, 21)
        Me.btnSelTodos.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.btnSelTodos.Name = "btnSelTodos"
        Me.btnSelTodos.Size = New System.Drawing.Size(267, 39)
        Me.btnSelTodos.TabIndex = 1
        Me.btnSelTodos.Text = "Selecionar Todos "
        Me.btnSelTodos.UseVisualStyleBackColor = True
        '
        'btnDesSelTodos
        '
        Me.btnDesSelTodos.Location = New System.Drawing.Point(267, 21)
        Me.btnDesSelTodos.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.btnDesSelTodos.Name = "btnDesSelTodos"
        Me.btnDesSelTodos.Size = New System.Drawing.Size(267, 39)
        Me.btnDesSelTodos.TabIndex = 2
        Me.btnDesSelTodos.TabStop = False
        Me.btnDesSelTodos.Text = "Desmarcar Todos"
        Me.btnDesSelTodos.UseVisualStyleBackColor = True
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.SystemColors.ControlDark
        Me.Panel1.Controls.Add(Me.btnOK)
        Me.Panel1.Controls.Add(Me.btnSelTodos)
        Me.Panel1.Controls.Add(Me.btnDesSelTodos)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.Panel1.Location = New System.Drawing.Point(0, 691)
        Me.Panel1.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(800, 75)
        Me.Panel1.TabIndex = 4
        '
        'btnOK
        '
        Me.btnOK.Location = New System.Drawing.Point(532, 21)
        Me.btnOK.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.btnOK.Name = "btnOK"
        Me.btnOK.Size = New System.Drawing.Size(267, 39)
        Me.btnOK.TabIndex = 3
        Me.btnOK.TabStop = False
        Me.btnOK.Text = "OK"
        Me.btnOK.UseVisualStyleBackColor = True
        '
        'FormSelecao
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.DarkBlue
        Me.ClientSize = New System.Drawing.Size(800, 766)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.treeModelos)
        Me.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Name = "FormSelecao"
        Me.Opacity = 0.9R
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        Me.Text = "Formulário de Seleção - Developed by Kreimeier & Machado"
        Me.Panel1.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents treeModelos As Windows.Forms.TreeView
    Friend WithEvents btnSelTodos As Windows.Forms.Button
    Friend WithEvents btnDesSelTodos As Windows.Forms.Button
    Friend WithEvents Panel1 As Windows.Forms.Panel
    Friend WithEvents btnOK As Windows.Forms.Button
End Class
