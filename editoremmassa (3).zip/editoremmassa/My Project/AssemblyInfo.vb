﻿Imports System
Imports System.Reflection
Imports System.Runtime.InteropServices

' As informações gerais sobre um assembly são controladas por
' conjunto de atributos. Altere estes valores de atributo para modificar as informações
' associadas a um assembly.

' Revise os valores dos atributos do assembly

<Assembly: AssemblyTitle("RegeneradordeEspessura")>
<Assembly: AssemblyDescription("")>
<Assembly: AssemblyCompany("")>
<Assembly: AssemblyProduct("RegeneradordeEspessura")>
<Assembly: AssemblyCopyright("Copyright ©  2025")>
<Assembly: AssemblyTrademark("")>

<Assembly: ComVisible(True)>

'O GUID a seguir será destinado à ID de typelib se este projeto for exposto para COM
<Assembly: Guid("0339a3ca-416b-4f3d-882b-41486a7ccd50")>

' As informações da versão de um assembly consistem nos quatro valores a seguir:
'
'      Versão Principal
'      Versão Secundária 
'      Número da Versão
'      Revisão
'

<Assembly: AssemblyVersion("1.0.0.0")>
<Assembly: AssemblyFileVersion("1.0.0.0")>
