﻿Imports System.Windows.Forms

Public Class FormPropriedades

    ' Variável para armazenar os dados aplicados
    Private _dados As DadosPropriedades

    Public Sub New()
        InitializeComponent()
    End Sub

    ' Função que retorna os dados preenchidos no formulário
    Public Function ObterDados() As DadosPropriedades
        Dim d As New DadosPropriedades With {
            .Titulo = txtTitulo.Text.Trim(),
            .Autor = txtAutor.Text.Trim(),
            .Responsavel = txtResponsavel.Text.Trim(),
            .Empresa = txtEmpresa.Text.Trim(),
            .Projetista = txtProjetista.Text.Trim(),
            .Engenheiro = txtEngenheiro.Text.Trim(),
            .Fornecedor = cmbFornecedor.Text.Trim(),
            .WebLink = cmbWebLink.Text.Trim(),
            .Assunto = txtAssunto.Text.Trim(),
            .DataCriacao = dtpData.Value,
            .Acabamento = cmbAcabamento.Text.Trim()   ' <-- Novo campo
        }
        Return d
    End Function

    Private Sub FormPropriedades_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ' Preencher data padrão
        dtpData.Value = Date.Now

        ' Preencher ComboBox de fornecedores
        cmbFornecedor.Items.Clear()
        cmbFornecedor.Items.Add("LIGA AUTOMAÇÃO EM EQUIPAMENTOS INDUSTRIAIS")
        cmbFornecedor.Items.Add("DOMA TECNOLOGIA EM EQUIPAMENTOS INDUSTRIAIS")
        cmbFornecedor.DropDownStyle = ComboBoxStyle.DropDown

        ' Preencher ComboBox de Weblink
        cmbWebLink.Items.Clear()
        cmbWebLink.Items.Add("engenharia@ligaeq.ind.br")
        cmbWebLink.Items.Add("engenharia@doma.ind.br")
        cmbWebLink.DropDownStyle = ComboBoxStyle.DropDown

        ' Preencher ComboBox de Acabamentos
        Dim acabamentosDisponiveis As New List(Of String) From {
            "JATEADO",
            "TREME-TREME",
            "ESCOVADO",
            "POLIDO",
            "USINADO",
            "DECAPADO",
            "NATURAL",
            "NATURAL / DECAPADO",
            "NATURAL / USINADO",
            "PINTADO",
            "GALVANIZADO A FRIO",
            "N/A"
        }
        cmbAcabamento.Items.Clear()
        cmbAcabamento.Items.AddRange(acabamentosDisponiveis.ToArray())
        cmbAcabamento.DropDownStyle = ComboBoxStyle.DropDown
        cmbAcabamento.SelectedItem = "N/A"   ' Valor padrão

        ' Texto padrão no campo Assunto
        txtAssunto.Text = "=<Part Number>"
    End Sub

    ' Botão OK: aplica os dados e fecha o formulário
    Private Sub btnOK_Click(sender As Object, e As EventArgs) Handles btnOK.Click
        _dados = ObterDados()
        Me.DialogResult = DialogResult.OK
        Me.Close()
    End Sub

    ' Função para recuperar os dados aplicados externamente
    Public Function GetDadosAplicados() As DadosPropriedades
        Return _dados
    End Function

End Class

' Classe que representa os dados do formulário
Public Class DadosPropriedades
    Public Property Titulo As String
    Public Property Autor As String
    Public Property Responsavel As String
    Public Property Empresa As String
    Public Property Projetista As String
    Public Property Engenheiro As String
    Public Property Fornecedor As String
    Public Property WebLink As String
    Public Property Assunto As String
    Public Property DataCriacao As Date
    Public Property Acabamento As String   ' <-- Novo membro
End Class
