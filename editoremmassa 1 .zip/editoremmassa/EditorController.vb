﻿Imports Inventor
Imports System.Windows.Forms

Public Class EditorController

    Private ReadOnly _app As Inventor.Application

    Public Sub New(app As Inventor.Application)
        _app = app
    End Sub

    Public Sub Executar()

        ' Garantir que um assembly está aberto
        If _app.ActiveDocumentType <> DocumentTypeEnum.kAssemblyDocumentObject Then
            MessageBox.Show("Abra uma montagem (.iam) antes de rodar esta função.", "Erro")
            Exit Sub
        End If

        Dim oAsmDoc As AssemblyDocument = _app.ActiveDocument

        ' -------------------------------
        ' 1) ABRE FORMULÁRIO DE SELEÇÃO
        ' -------------------------------
        Dim frmSel As New FormSelecao()
        frmSel.MontarArvore(ObterBOM(oAsmDoc))

        If frmSel.ShowDialog() <> DialogResult.OK Then Exit Sub

        Dim modelosSelecionados As List(Of Document) = frmSel.RetornarDocumentos(_app)

        If modelosSelecionados.Count = 0 Then
            MessageBox.Show("Nenhum modelo selecionado.", "Aviso")
            Exit Sub
        End If

        ' -------------------------------
        ' 2) ABRE FORMULÁRIO DE PROPRIEDADES
        ' -------------------------------
        Dim frmProp As New FormPropriedades()

        If frmProp.ShowDialog() <> DialogResult.OK Then Exit Sub

        ' Dados preenchidos pelo usuário
        Dim dados = frmProp.ObterDados()

        ' -------------------------------
        ' 3) PROCESSA E SALVA DOCUMENTOS
        ' -------------------------------
        For Each oDoc In modelosSelecionados
            Try
                Dim partNumber As String = ""
                Try : partNumber = oDoc.PropertySets.Item("Design Tracking Properties").Item("Part Number").Value : Catch : End Try

                Dim assunto As String = dados.Assunto
                If assunto.Trim() = "=<Part Number>" Then assunto = partNumber

                AplicarPropriedades(oDoc,
                                    dados.DataCriacao,
                                    dados.Titulo,
                                    dados.Autor,
                                    assunto,
                                    dados.Responsavel,
                                    dados.Empresa,
                                    dados.Projetista,
                                    dados.Engenheiro,
                                    dados.Fornecedor,
                                    dados.WebLink)

                oDoc.Save()

            Catch ex As Exception
                MessageBox.Show("Erro ao atualizar " & oDoc.DisplayName & vbCrLf & ex.Message)
            End Try
        Next

        MessageBox.Show("Propriedades aplicadas com sucesso!", "Finalizado")
    End Sub
    Public Function ObterBOM(asmDoc As AssemblyDocument) As BOMRowsEnumerator
        Try
            Dim bom = asmDoc.ComponentDefinition.BOM
            bom.StructuredViewEnabled = True
            bom.StructuredViewFirstLevelOnly = False

            For Each view As BOMView In bom.BOMViews
                If view.ViewType = BOMViewTypeEnum.kStructuredBOMViewType Then
                    Return view.BOMRows
                End If
            Next

        Catch
        End Try

        Return Nothing
    End Function
    Public Sub AplicarPropriedades(doc As Document,
                               dataCriacao As Date,
                               titulo As String,
                               autor As String,
                               assunto As String,
                               responsavel As String,
                               empresa As String,
                               projetista As String,
                               engenheiro As String,
                               fornecedor As String,
                               webLink As String)

        Dim summary = doc.PropertySets.Item("Inventor Summary Information")
        Dim docSummary = doc.PropertySets.Item("Inventor Document Summary Information")
        Dim design = doc.PropertySets.Item("Design Tracking Properties")

        SetProp(summary, "Title", titulo)
        SetProp(summary, "Author", autor)
        SetProp(summary, "Subject", assunto)

        SetProp(docSummary, "Manager", responsavel)
        SetProp(docSummary, "Company", empresa)

        SetProp(design, "Designer", projetista)
        SetProp(design, "Engineer", engenheiro)
        SetProp(design, "Vendor", fornecedor)
        SetProp(design, "Catalog Web Link", webLink)

        SetProp(design, "Creation Time", dataCriacao)
    End Sub

    Private Sub SetProp(propSet As PropertySet, propName As String, value As Object)
        If value Is Nothing OrElse value.ToString.Trim = "" Then Exit Sub
        Try
            propSet.Item(propName).Value = value
        Catch
            propSet.Add(value, propName)
        End Try
    End Sub

End Class

