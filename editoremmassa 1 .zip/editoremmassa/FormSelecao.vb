﻿Imports Inventor
Imports System.Windows.Forms

Public Class FormSelecao

    Public Sub New()
        InitializeComponent()
    End Sub

    ' Controles criados pelo designer:
    ' TreeView: treeModelos
    ' Button: btnOK, btnSelTodos, btnDesSelTodos

    ' ==========================
    '  MONTA A ÁRVORE DO BOM
    ' ==========================
    Public Sub MontarArvore(bom As BOMRowsEnumerator)

        treeModelos.Nodes.Clear()

        If bom Is Nothing Then Exit Sub

        For Each row As BOMRow In bom
            AdicionarBOMNode(row, treeModelos.Nodes)
        Next

        treeModelos.ExpandAll()
    End Sub

    Private Sub AdicionarBOMNode(row As BOMRow, parent As TreeNodeCollection)
        Try
            Dim docPath As String = ""
            Dim itemName As String = row.ItemNumber
            Dim partName As String = ""

            If row.ComponentDefinitions.Count > 0 Then
                Dim doc = row.ComponentDefinitions.Item(1).Document
                docPath = doc.FullDocumentName
                Try : partName = doc.PropertySets.Item("Design Tracking Properties").Item("Part Number").Value : Catch : End Try
            End If

            Dim labelText As String = $"{itemName} - {If(partName = "", itemName, partName)}"

            Dim node As New TreeNode(labelText) With {
                .Checked = False,
                .Tag = docPath
            }

            parent.Add(node)

            If row.ChildRows IsNot Nothing Then
                For Each child As BOMRow In row.ChildRows
                    AdicionarBOMNode(child, node.Nodes)
                Next
            End If

        Catch
        End Try
    End Sub

    ' ==========================
    '  RETORNAR DOCUMENTOS
    ' ==========================
    Public Function RetornarDocumentos(app As Inventor.Application) As List(Of Document)

        Dim lista As New List(Of Document)
        ObterSelecionados(treeModelos.Nodes, lista, app)
        Return lista

    End Function

    Private Sub ObterSelecionados(nodes As TreeNodeCollection,
                                  lista As List(Of Document),
                                  app As Inventor.Application)

        For Each n As TreeNode In nodes

            If n.Checked AndAlso n.Tag IsNot Nothing Then
                Dim path As String = CStr(n.Tag)

                If IO.File.Exists(path) Then
                    Try
                        lista.Add(app.Documents.Open(path, False))
                    Catch
                    End Try
                End If
            End If

            ObterSelecionados(n.Nodes, lista, app)
        Next

    End Sub

    ' ==========================
    '  BOTÕES
    ' ==========================

    Private Sub btnSelTodos_Click(sender As Object, e As EventArgs) Handles btnSelTodos.Click
        MarcarTudo(treeModelos.Nodes, True)
    End Sub

    Private Sub btnDesSelTodos_Click(sender As Object, e As EventArgs) Handles btnDesSelTodos.Click
        MarcarTudo(treeModelos.Nodes, False)
    End Sub

    Private Sub MarcarTudo(nodes As TreeNodeCollection, marcado As Boolean)
        For Each n As TreeNode In nodes
            n.Checked = marcado
            MarcarTudo(n.Nodes, marcado)
        Next
    End Sub

    Private Sub btnOK_Click(sender As Object, e As EventArgs) Handles btnOK.Click

        If Not ExisteSelecionado(treeModelos.Nodes) Then
            MessageBox.Show("Selecione ao menos um modelo.", "Aviso")
            Exit Sub
        End If

        Me.DialogResult = DialogResult.OK
        Me.Close()

    End Sub

    Private Function ExisteSelecionado(nodes As TreeNodeCollection) As Boolean
        For Each n As TreeNode In nodes
            If n.Checked OrElse ExisteSelecionado(n.Nodes) Then Return True
        Next
        Return False
    End Function

    Private Sub FormSelecao_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub btnSelTodos_Click_1(sender As Object, e As EventArgs) Handles btnSelTodos.Click

    End Sub

    Private Sub btnOK_Click_1(sender As Object, e As EventArgs)

    End Sub
End Class
