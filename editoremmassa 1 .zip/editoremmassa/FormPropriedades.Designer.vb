﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FormPropriedades
    Inherits System.Windows.Forms.Form

    'Descartar substituições de formulário para limpar a lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Exigido pelo Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'OBSERVAÇÃO: o procedimento a seguir é exigido pelo Windows Form Designer
    'Pode ser modificado usando o Windows Form Designer.  
    'Não o modifique usando o editor de códigos.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.txtTitulo = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.txtAutor = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.txtResponsavel = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.txtEmpresa = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.txtProjetista = New System.Windows.Forms.TextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.txtEngenheiro = New System.Windows.Forms.TextBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.dtpData = New System.Windows.Forms.DateTimePicker()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.txtAssunto = New System.Windows.Forms.TextBox()
        Me.btnOK = New System.Windows.Forms.Button()
        Me.cmbFornecedor = New System.Windows.Forms.ComboBox()
        Me.cmbWebLink = New System.Windows.Forms.ComboBox()
        Me.SuspendLayout()
        '
        'txtTitulo
        '
        Me.txtTitulo.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.txtTitulo.Location = New System.Drawing.Point(11, 44)
        Me.txtTitulo.Margin = New System.Windows.Forms.Padding(2)
        Me.txtTitulo.Name = "txtTitulo"
        Me.txtTitulo.Size = New System.Drawing.Size(550, 26)
        Me.txtTitulo.TabIndex = 0
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.Label1.Location = New System.Drawing.Point(11, 14)
        Me.Label1.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(47, 20)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "Título"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.Label2.Location = New System.Drawing.Point(11, 84)
        Me.Label2.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(48, 20)
        Me.Label2.TabIndex = 3
        Me.Label2.Text = "Autor"
        '
        'txtAutor
        '
        Me.txtAutor.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.txtAutor.Location = New System.Drawing.Point(11, 114)
        Me.txtAutor.Margin = New System.Windows.Forms.Padding(2)
        Me.txtAutor.Name = "txtAutor"
        Me.txtAutor.Size = New System.Drawing.Size(550, 26)
        Me.txtAutor.TabIndex = 2
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.Label3.Location = New System.Drawing.Point(11, 154)
        Me.Label3.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(101, 20)
        Me.Label3.TabIndex = 5
        Me.Label3.Text = "Responsável"
        '
        'txtResponsavel
        '
        Me.txtResponsavel.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.txtResponsavel.Location = New System.Drawing.Point(11, 184)
        Me.txtResponsavel.Margin = New System.Windows.Forms.Padding(2)
        Me.txtResponsavel.Name = "txtResponsavel"
        Me.txtResponsavel.Size = New System.Drawing.Size(549, 26)
        Me.txtResponsavel.TabIndex = 4
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.Label4.Location = New System.Drawing.Point(11, 224)
        Me.Label4.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(73, 20)
        Me.Label4.TabIndex = 7
        Me.Label4.Text = "Empresa"
        '
        'txtEmpresa
        '
        Me.txtEmpresa.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.txtEmpresa.Location = New System.Drawing.Point(11, 254)
        Me.txtEmpresa.Margin = New System.Windows.Forms.Padding(2)
        Me.txtEmpresa.Name = "txtEmpresa"
        Me.txtEmpresa.Size = New System.Drawing.Size(549, 26)
        Me.txtEmpresa.TabIndex = 6
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.Label5.Location = New System.Drawing.Point(11, 294)
        Me.Label5.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(75, 20)
        Me.Label5.TabIndex = 9
        Me.Label5.Text = "Projetista"
        '
        'txtProjetista
        '
        Me.txtProjetista.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.txtProjetista.Location = New System.Drawing.Point(11, 324)
        Me.txtProjetista.Margin = New System.Windows.Forms.Padding(2)
        Me.txtProjetista.Name = "txtProjetista"
        Me.txtProjetista.Size = New System.Drawing.Size(550, 26)
        Me.txtProjetista.TabIndex = 8
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.Label6.Location = New System.Drawing.Point(11, 364)
        Me.Label6.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(91, 20)
        Me.Label6.TabIndex = 11
        Me.Label6.Text = "Engenheiro"
        '
        'txtEngenheiro
        '
        Me.txtEngenheiro.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.txtEngenheiro.Location = New System.Drawing.Point(11, 394)
        Me.txtEngenheiro.Margin = New System.Windows.Forms.Padding(2)
        Me.txtEngenheiro.Name = "txtEngenheiro"
        Me.txtEngenheiro.Size = New System.Drawing.Size(550, 26)
        Me.txtEngenheiro.TabIndex = 10
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.Label7.Location = New System.Drawing.Point(11, 433)
        Me.Label7.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(91, 20)
        Me.Label7.TabIndex = 13
        Me.Label7.Text = "Fornecedor"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.Label8.Location = New System.Drawing.Point(11, 505)
        Me.Label8.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(71, 20)
        Me.Label8.TabIndex = 15
        Me.Label8.Text = "WebLink"
        '
        'dtpData
        '
        Me.dtpData.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.dtpData.Location = New System.Drawing.Point(11, 608)
        Me.dtpData.Margin = New System.Windows.Forms.Padding(2)
        Me.dtpData.Name = "dtpData"
        Me.dtpData.Size = New System.Drawing.Size(551, 26)
        Me.dtpData.TabIndex = 16
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.Label9.Location = New System.Drawing.Point(11, 578)
        Me.Label9.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(124, 20)
        Me.Label9.TabIndex = 17
        Me.Label9.Text = "Data de Criação"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.Label10.Location = New System.Drawing.Point(11, 648)
        Me.Label10.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(68, 20)
        Me.Label10.TabIndex = 19
        Me.Label10.Text = "Assunto"
        '
        'txtAssunto
        '
        Me.txtAssunto.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.txtAssunto.Location = New System.Drawing.Point(11, 678)
        Me.txtAssunto.Margin = New System.Windows.Forms.Padding(2)
        Me.txtAssunto.Name = "txtAssunto"
        Me.txtAssunto.Size = New System.Drawing.Size(550, 26)
        Me.txtAssunto.TabIndex = 18
        '
        'btnOK
        '
        Me.btnOK.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.btnOK.Location = New System.Drawing.Point(360, 724)
        Me.btnOK.Margin = New System.Windows.Forms.Padding(2)
        Me.btnOK.Name = "btnOK"
        Me.btnOK.Size = New System.Drawing.Size(200, 28)
        Me.btnOK.TabIndex = 21
        Me.btnOK.Text = "ok"
        Me.btnOK.UseVisualStyleBackColor = True
        '
        'cmbFornecedor
        '
        Me.cmbFornecedor.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.cmbFornecedor.FormattingEnabled = True
        Me.cmbFornecedor.Location = New System.Drawing.Point(11, 464)
        Me.cmbFornecedor.Name = "cmbFornecedor"
        Me.cmbFornecedor.Size = New System.Drawing.Size(550, 28)
        Me.cmbFornecedor.TabIndex = 22
        '
        'cmbWebLink
        '
        Me.cmbWebLink.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.cmbWebLink.FormattingEnabled = True
        Me.cmbWebLink.Location = New System.Drawing.Point(11, 536)
        Me.cmbWebLink.Name = "cmbWebLink"
        Me.cmbWebLink.Size = New System.Drawing.Size(550, 28)
        Me.cmbWebLink.TabIndex = 23
        '
        'FormPropriedades
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.DarkGray
        Me.ClientSize = New System.Drawing.Size(576, 763)
        Me.Controls.Add(Me.cmbWebLink)
        Me.Controls.Add(Me.cmbFornecedor)
        Me.Controls.Add(Me.btnOK)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.txtAssunto)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.dtpData)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.txtEngenheiro)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.txtProjetista)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.txtEmpresa)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.txtResponsavel)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.txtAutor)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.txtTitulo)
        Me.Margin = New System.Windows.Forms.Padding(2)
        Me.Name = "FormPropriedades"
        Me.Opacity = 0.98R
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        Me.Text = "Formulário de Propriedades"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents txtTitulo As Windows.Forms.TextBox
    Friend WithEvents Label1 As Windows.Forms.Label
    Friend WithEvents Label2 As Windows.Forms.Label
    Friend WithEvents txtAutor As Windows.Forms.TextBox
    Friend WithEvents Label3 As Windows.Forms.Label
    Friend WithEvents txtResponsavel As Windows.Forms.TextBox
    Friend WithEvents Label4 As Windows.Forms.Label
    Friend WithEvents txtEmpresa As Windows.Forms.TextBox
    Friend WithEvents Label5 As Windows.Forms.Label
    Friend WithEvents txtProjetista As Windows.Forms.TextBox
    Friend WithEvents Label6 As Windows.Forms.Label
    Friend WithEvents txtEngenheiro As Windows.Forms.TextBox
    Friend WithEvents Label7 As Windows.Forms.Label
    Friend WithEvents Label8 As Windows.Forms.Label
    Friend WithEvents dtpData As Windows.Forms.DateTimePicker
    Friend WithEvents Label9 As Windows.Forms.Label
    Friend WithEvents Label10 As Windows.Forms.Label
    Friend WithEvents txtAssunto As Windows.Forms.TextBox
    Friend WithEvents btnOK As Windows.Forms.Button
    Friend WithEvents cmbFornecedor As Windows.Forms.ComboBox
    Friend WithEvents cmbWebLink As Windows.Forms.ComboBox
End Class
