﻿Imports System.Drawing
Imports System.IO
Imports System.Reflection
Imports System.Runtime.InteropServices
Imports System.Windows.Forms
Imports Inventor
Imports stdole

<ComVisible(True)>
<Guid("c2aa6312-7c94-42b7-a892-cf0fdb0d2929")> ' GUID do AddIn
Public Class StandardAddInServerCategoriaAcabamento
    Implements ApplicationAddInServer

    Private _inventorApp As Inventor.Application
    Private _automacaoCategoria As AutomacaoCategoriaEAcabamento
    Private botaoCategoria As ButtonDefinition

    Public Sub Activate(addInSiteObject As ApplicationAddInSite, firstTime As Boolean) Implements ApplicationAddInServer.Activate
        _inventorApp = addInSiteObject.Application
        _automacaoCategoria = New AutomacaoCategoriaEAcabamento(_inventorApp)

        If firstTime Then
            Try
                Dim controlDefs As ControlDefinitions = _inventorApp.CommandManager.ControlDefinitions
                Dim assembly As Assembly = Assembly.GetExecutingAssembly()

                ' Nome correto dos ícones incorporados (ajuste conforme seu namespace/projeto)
                Dim recursoIconePequeno As String = "CategoriaEAcabamento.16x16.ico"
                Dim recursoIconeGrande As String = "CategoriaEAcabamento.32x32.ico"

                Dim smallPicture As IPictureDisp = Nothing
                Dim largePicture As IPictureDisp = Nothing

                Using streamPequeno As Stream = assembly.GetManifestResourceStream(recursoIconePequeno)
                    If streamPequeno IsNot Nothing Then
                        smallPicture = IconToIPictureDisp(New Icon(streamPequeno))
                    End If
                End Using

                Using streamGrande As Stream = assembly.GetManifestResourceStream(recursoIconeGrande)
                    If streamGrande IsNot Nothing Then
                        largePicture = IconToIPictureDisp(New Icon(streamGrande))
                    End If
                End Using

                ' Criar ou recuperar botão
                Try
                    botaoCategoria = DirectCast(controlDefs.Item("MyCompany_AplicarCategoria"), ButtonDefinition)
                Catch
                    botaoCategoria = controlDefs.AddButtonDefinition(
                        "Categoria" & vbCrLf & "Acabamento",
                        "MyCompany_AplicarCategoria",
                        CommandTypesEnum.kShapeEditCmdType,
                        "{8872b3f8-1758-4405-80fb-c702857ba369}", ' GUID do botão
                        "Executa regra iLogic para aplicar categoria e acabamento",
                        "Aplicar Propriedades",
                        smallPicture,
                        largePicture)
                End Try

                AddHandler botaoCategoria.OnExecute, AddressOf BotaoCategoria_OnExecute

                ' Inserir botão na Ribbon Assembly > Tools
                Dim ribbon As Ribbon = _inventorApp.UserInterfaceManager.Ribbons("Assembly")
                Dim abaTools As RibbonTab = ribbon.RibbonTabs("id_TabTools")

                ' Criar painel se necessário
                Dim painel As RibbonPanel
                Try
                    painel = abaTools.RibbonPanels.Item("PainelCategoriaAcabamento")
                Catch
                    painel = abaTools.RibbonPanels.Add(
                        "Aplicar Categoria",
                        "PainelCategoriaAcabamento",
                        "f4218c11-6fa2-4318-bcee-0b123456abcd" ' GUID único
                    )
                End Try

                ' Adicionar botão se ainda não estiver presente
                If Not painel.CommandControls.Cast(Of CommandControl).
                    Any(Function(c) c.ControlDefinition.InternalName = "MyCompany_AplicarCategoria") Then

                    painel.CommandControls.AddButton(botaoCategoria, True)
                End If

            Catch ex As Exception
                MessageBox.Show("Erro ao criar botão: " & ex.Message)
            End Try
        End If
    End Sub

    Public Sub Deactivate() Implements ApplicationAddInServer.Deactivate
        _inventorApp = Nothing
        _automacaoCategoria = Nothing
    End Sub

    Public Sub ExecuteCommand(commandID As Integer) Implements ApplicationAddInServer.ExecuteCommand
        ' Não utilizado
    End Sub

    Private Sub BotaoCategoria_OnExecute(context As NameValueMap)
        Try
            _automacaoCategoria.Aplicar()
        Catch ex As Exception
            MessageBox.Show("Erro ao executar: " & ex.Message)
        End Try
    End Sub

    ' Conversão de Icon para IPictureDisp
    Private Function IconToIPictureDisp(icon As Icon) As IPictureDisp
        Dim bmp As Bitmap = icon.ToBitmap()
        Return AxHostConverter.ImageToPictureDisp(bmp)
    End Function

    Private Class AxHostConverter
        Inherits AxHost
        Private Sub New()
            MyBase.New(String.Empty)
        End Sub

        Public Shared Function ImageToPictureDisp(image As Image) As IPictureDisp
            Return CType(GetIPictureDispFromPicture(image), IPictureDisp)
        End Function
    End Class

    Public ReadOnly Property Automation As Object Implements ApplicationAddInServer.Automation
        Get
            Return _automacaoCategoria
        End Get
    End Property
End Class

