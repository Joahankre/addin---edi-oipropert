﻿Imports System.Runtime.InteropServices
Imports Inventor

<ComVisible(True)>
<Guid("cd91e779-12ce-408e-afa6-557ad8ffe48c")>
<ClassInterface(ClassInterfaceType.None)>
Public Class AutomacaoCategoriaEAcabamento
    Implements IAplicarCategoriaEAcabamento

    Private ReadOnly _app As Inventor.Application

    Public Sub New(app As Inventor.Application)
        _app = app
    End Sub

    Public Sub Aplicar() Implements IAplicarCategoriaEAcabamento.Aplicar
        Dim executor As New ExecutorDeCategoriaEAcabamento(_app)
        executor.Executar()
    End Sub
End Class
