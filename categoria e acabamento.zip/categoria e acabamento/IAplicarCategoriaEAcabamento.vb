﻿Imports System.Runtime.InteropServices

<ComVisible(True)>
<Guid("6146aa15-e06e-405f-b988-6dc658781f06")>
Public Interface IAplicarCategoriaEAcabamento
    Sub Aplicar()
End Interface
