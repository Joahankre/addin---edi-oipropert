﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FormPropriedades
    Inherits System.Windows.Forms.Form

    'Descartar substituições de formulário para limpar a lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Exigido pelo Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'OBSERVAÇÃO: o procedimento a seguir é exigido pelo Windows Form Designer
    'Pode ser modificado usando o Windows Form Designer.  
    'Não o modifique usando o editor de códigos.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.txtTitulo = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.txtAutor = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.txtResponsavel = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.txtEmpresa = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.txtProjetista = New System.Windows.Forms.TextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.txtEngenheiro = New System.Windows.Forms.TextBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.dtpData = New System.Windows.Forms.DateTimePicker()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.txtAssunto = New System.Windows.Forms.TextBox()
        Me.btnOK = New System.Windows.Forms.Button()
        Me.cmbFornecedor = New System.Windows.Forms.ComboBox()
        Me.cmbWebLink = New System.Windows.Forms.ComboBox()
        Me.TableLayoutPanel1 = New System.Windows.Forms.TableLayoutPanel()
        Me.TableLayoutPanel1.SuspendLayout()
        Me.SuspendLayout()
        '
        'txtTitulo
        '
        Me.txtTitulo.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.txtTitulo.Location = New System.Drawing.Point(195, 22)
        Me.txtTitulo.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.txtTitulo.Name = "txtTitulo"
        Me.txtTitulo.Size = New System.Drawing.Size(650, 30)
        Me.txtTitulo.TabIndex = 0
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.Label1.Location = New System.Drawing.Point(3, 20)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(60, 25)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "Título"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.Label2.Location = New System.Drawing.Point(3, 65)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(59, 25)
        Me.Label2.TabIndex = 3
        Me.Label2.Text = "Autor"
        '
        'txtAutor
        '
        Me.txtAutor.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.txtAutor.Location = New System.Drawing.Point(195, 67)
        Me.txtAutor.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.txtAutor.Name = "txtAutor"
        Me.txtAutor.Size = New System.Drawing.Size(650, 30)
        Me.txtAutor.TabIndex = 2
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.Label3.Location = New System.Drawing.Point(3, 110)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(125, 25)
        Me.Label3.TabIndex = 5
        Me.Label3.Text = "Responsável"
        '
        'txtResponsavel
        '
        Me.txtResponsavel.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.txtResponsavel.Location = New System.Drawing.Point(195, 112)
        Me.txtResponsavel.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.txtResponsavel.Name = "txtResponsavel"
        Me.txtResponsavel.Size = New System.Drawing.Size(650, 30)
        Me.txtResponsavel.TabIndex = 4
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.Label4.Location = New System.Drawing.Point(3, 155)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(90, 25)
        Me.Label4.TabIndex = 7
        Me.Label4.Text = "Empresa"
        '
        'txtEmpresa
        '
        Me.txtEmpresa.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.txtEmpresa.Location = New System.Drawing.Point(195, 157)
        Me.txtEmpresa.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.txtEmpresa.Name = "txtEmpresa"
        Me.txtEmpresa.Size = New System.Drawing.Size(650, 30)
        Me.txtEmpresa.TabIndex = 6
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.Label5.Location = New System.Drawing.Point(3, 200)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(92, 25)
        Me.Label5.TabIndex = 9
        Me.Label5.Text = "Projetista"
        '
        'txtProjetista
        '
        Me.txtProjetista.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.txtProjetista.Location = New System.Drawing.Point(195, 202)
        Me.txtProjetista.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.txtProjetista.Name = "txtProjetista"
        Me.txtProjetista.Size = New System.Drawing.Size(650, 30)
        Me.txtProjetista.TabIndex = 8
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.Label6.Location = New System.Drawing.Point(3, 245)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(112, 25)
        Me.Label6.TabIndex = 11
        Me.Label6.Text = "Engenheiro"
        '
        'txtEngenheiro
        '
        Me.txtEngenheiro.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.txtEngenheiro.Location = New System.Drawing.Point(195, 247)
        Me.txtEngenheiro.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.txtEngenheiro.Name = "txtEngenheiro"
        Me.txtEngenheiro.Size = New System.Drawing.Size(650, 30)
        Me.txtEngenheiro.TabIndex = 10
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.Label7.Location = New System.Drawing.Point(3, 290)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(112, 25)
        Me.Label7.TabIndex = 13
        Me.Label7.Text = "Fornecedor"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.Label8.Location = New System.Drawing.Point(3, 335)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(90, 25)
        Me.Label8.TabIndex = 15
        Me.Label8.Text = "WebLink"
        '
        'dtpData
        '
        Me.dtpData.CalendarTitleForeColor = System.Drawing.Color.Aqua
        Me.dtpData.CalendarTrailingForeColor = System.Drawing.SystemColors.HotTrack
        Me.dtpData.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.dtpData.Location = New System.Drawing.Point(195, 382)
        Me.dtpData.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.dtpData.Name = "dtpData"
        Me.dtpData.Size = New System.Drawing.Size(650, 30)
        Me.dtpData.TabIndex = 16
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.Label9.Location = New System.Drawing.Point(3, 380)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(153, 25)
        Me.Label9.TabIndex = 17
        Me.Label9.Text = "Data de Criação"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.Label10.Location = New System.Drawing.Point(3, 425)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(84, 25)
        Me.Label10.TabIndex = 19
        Me.Label10.Text = "Assunto"
        '
        'txtAssunto
        '
        Me.txtAssunto.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.txtAssunto.Location = New System.Drawing.Point(195, 427)
        Me.txtAssunto.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.txtAssunto.Name = "txtAssunto"
        Me.txtAssunto.Size = New System.Drawing.Size(650, 30)
        Me.txtAssunto.TabIndex = 18
        '
        'btnOK
        '
        Me.btnOK.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.btnOK.Location = New System.Drawing.Point(3, 472)
        Me.btnOK.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.btnOK.Name = "btnOK"
        Me.btnOK.Size = New System.Drawing.Size(186, 34)
        Me.btnOK.TabIndex = 21
        Me.btnOK.Text = "ok"
        Me.btnOK.UseVisualStyleBackColor = True
        '
        'cmbFornecedor
        '
        Me.cmbFornecedor.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.cmbFornecedor.FormattingEnabled = True
        Me.cmbFornecedor.Location = New System.Drawing.Point(196, 294)
        Me.cmbFornecedor.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.cmbFornecedor.Name = "cmbFornecedor"
        Me.cmbFornecedor.Size = New System.Drawing.Size(650, 33)
        Me.cmbFornecedor.TabIndex = 22
        '
        'cmbWebLink
        '
        Me.cmbWebLink.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.cmbWebLink.FormattingEnabled = True
        Me.cmbWebLink.Location = New System.Drawing.Point(196, 339)
        Me.cmbWebLink.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.cmbWebLink.Name = "cmbWebLink"
        Me.cmbWebLink.Size = New System.Drawing.Size(650, 33)
        Me.cmbWebLink.TabIndex = 23
        '
        'TableLayoutPanel1
        '
        Me.TableLayoutPanel1.ColumnCount = 2
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle())
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel1.Controls.Add(Me.btnOK, 0, 11)
        Me.TableLayoutPanel1.Controls.Add(Me.txtAssunto, 1, 10)
        Me.TableLayoutPanel1.Controls.Add(Me.Label10, 0, 10)
        Me.TableLayoutPanel1.Controls.Add(Me.dtpData, 1, 9)
        Me.TableLayoutPanel1.Controls.Add(Me.Label9, 0, 9)
        Me.TableLayoutPanel1.Controls.Add(Me.cmbWebLink, 1, 8)
        Me.TableLayoutPanel1.Controls.Add(Me.Label8, 0, 8)
        Me.TableLayoutPanel1.Controls.Add(Me.cmbFornecedor, 1, 7)
        Me.TableLayoutPanel1.Controls.Add(Me.Label7, 0, 7)
        Me.TableLayoutPanel1.Controls.Add(Me.txtEngenheiro, 1, 6)
        Me.TableLayoutPanel1.Controls.Add(Me.Label6, 0, 6)
        Me.TableLayoutPanel1.Controls.Add(Me.txtProjetista, 1, 5)
        Me.TableLayoutPanel1.Controls.Add(Me.Label5, 0, 5)
        Me.TableLayoutPanel1.Controls.Add(Me.txtEmpresa, 1, 4)
        Me.TableLayoutPanel1.Controls.Add(Me.Label4, 0, 4)
        Me.TableLayoutPanel1.Controls.Add(Me.Label3, 0, 3)
        Me.TableLayoutPanel1.Controls.Add(Me.txtResponsavel, 1, 3)
        Me.TableLayoutPanel1.Controls.Add(Me.Label2, 0, 2)
        Me.TableLayoutPanel1.Controls.Add(Me.txtAutor, 1, 2)
        Me.TableLayoutPanel1.Controls.Add(Me.Label1, 0, 1)
        Me.TableLayoutPanel1.Controls.Add(Me.txtTitulo, 1, 1)
        Me.TableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TableLayoutPanel1.Location = New System.Drawing.Point(0, 0)
        Me.TableLayoutPanel1.Name = "TableLayoutPanel1"
        Me.TableLayoutPanel1.RowCount = 12
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 45.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 45.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 45.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 45.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 45.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 45.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 45.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 45.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 45.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 45.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20.0!))
        Me.TableLayoutPanel1.Size = New System.Drawing.Size(856, 512)
        Me.TableLayoutPanel1.TabIndex = 24
        '
        'FormPropriedades
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.LightCyan
        Me.ClientSize = New System.Drawing.Size(856, 512)
        Me.Controls.Add(Me.TableLayoutPanel1)
        Me.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Name = "FormPropriedades"
        Me.Opacity = 0.99R
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        Me.Text = "Formulário de Propriedades"
        Me.TableLayoutPanel1.ResumeLayout(False)
        Me.TableLayoutPanel1.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents txtTitulo As Windows.Forms.TextBox
    Friend WithEvents Label1 As Windows.Forms.Label
    Friend WithEvents Label2 As Windows.Forms.Label
    Friend WithEvents txtAutor As Windows.Forms.TextBox
    Friend WithEvents Label3 As Windows.Forms.Label
    Friend WithEvents txtResponsavel As Windows.Forms.TextBox
    Friend WithEvents Label4 As Windows.Forms.Label
    Friend WithEvents txtEmpresa As Windows.Forms.TextBox
    Friend WithEvents Label5 As Windows.Forms.Label
    Friend WithEvents txtProjetista As Windows.Forms.TextBox
    Friend WithEvents Label6 As Windows.Forms.Label
    Friend WithEvents txtEngenheiro As Windows.Forms.TextBox
    Friend WithEvents Label7 As Windows.Forms.Label
    Friend WithEvents Label8 As Windows.Forms.Label
    Friend WithEvents dtpData As Windows.Forms.DateTimePicker
    Friend WithEvents Label9 As Windows.Forms.Label
    Friend WithEvents Label10 As Windows.Forms.Label
    Friend WithEvents txtAssunto As Windows.Forms.TextBox
    Friend WithEvents btnOK As Windows.Forms.Button
    Friend WithEvents cmbFornecedor As Windows.Forms.ComboBox
    Friend WithEvents cmbWebLink As Windows.Forms.ComboBox
    Friend WithEvents TableLayoutPanel1 As Windows.Forms.TableLayoutPanel
End Class
