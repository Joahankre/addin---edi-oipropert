﻿Imports System.Windows.Forms

Public Class FormPropriedades

    ' Variável para armazenar os dados aplicados
    Private _dados As DadosPropriedades

    Public Sub New()
        InitializeComponent()
    End Sub

    ' Função que retorna os dados preenchidos no formulário
    Public Function ObterDados() As DadosPropriedades
        Dim d As New DadosPropriedades With {
            .Titulo = txtTitulo.Text.Trim(),
            .Autor = txtAutor.Text.Trim(),
            .Responsavel = txtResponsavel.Text.Trim(),
            .Empresa = txtEmpresa.Text.Trim(),
            .Projetista = txtProjetista.Text.Trim(),
            .Engenheiro = txtEngenheiro.Text.Trim(),
            .Fornecedor = cmbFornecedor.Text.Trim(),
            .WebLink = cmbWebLink.Text.Trim(),
            .Assunto = txtAssunto.Text.Trim(),
            .DataCriacao = dtpData.Value
        }
        Return d
    End Function
    Private Sub FormPropriedades_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        ' Preencher data padrão
        dtpData.Value = Date.Now

        ' Preencher ComboBox de fornecedores
        cmbFornecedor.Items.Clear()
        cmbFornecedor.Items.Add("LIGA AUTOMAÇÃO EM EQUIPAMENTOS INDUSTRIAIS")
        cmbFornecedor.Items.Add("DOMA TECNOLOGIA EM EQUIPAMENTOS INDUSTRIAIS")

        ' Permite que o usuário digite texto fora das opções (opcional)
        cmbFornecedor.DropDownStyle = ComboBoxStyle.DropDown

        ' Preencher ComboBox de Weblink
        cmbWebLink.Items.Clear()
        cmbWebLink.Items.Add("engenharia@ligaeq.ind.br")
        cmbWebLink.Items.Add("engenharia@doma.ind.br")

        ' Permite que o usuário digite texto fora das opções (opcional)
        cmbWebLink.DropDownStyle = ComboBoxStyle.DropDown

        ' Texto padrão no campo Assunto
        txtAssunto.Text = "=<Part Number>"

    End Sub

    ' Botão OK: aplica os dados e fecha o formulário
    Private Sub btnOK_Click(sender As Object, e As EventArgs) Handles btnOK.Click
        _dados = ObterDados()
        Me.DialogResult = DialogResult.OK
        Me.Close()
    End Sub


    ' Função para recuperar os dados aplicados externamente
    Public Function GetDadosAplicados() As DadosPropriedades
        Return _dados
    End Function

    Private Sub Label1_Click(sender As Object, e As EventArgs) Handles Label1.Click

    End Sub

    Private Sub Label2_Click(sender As Object, e As EventArgs) Handles Label2.Click

    End Sub

    Private Sub Label3_Click(sender As Object, e As EventArgs) Handles Label3.Click

    End Sub

    Private Sub Label4_Click(sender As Object, e As EventArgs) Handles Label4.Click

    End Sub

    Private Sub Label5_Click(sender As Object, e As EventArgs) Handles Label5.Click

    End Sub

    Private Sub Label6_Click(sender As Object, e As EventArgs) Handles Label6.Click

    End Sub

    Private Sub Label7_Click(sender As Object, e As EventArgs) Handles Label7.Click

    End Sub

    Private Sub Label8_Click(sender As Object, e As EventArgs) Handles Label8.Click

    End Sub

    Private Sub Label9_Click(sender As Object, e As EventArgs) Handles Label9.Click

    End Sub

    Private Sub Label10_Click(sender As Object, e As EventArgs) Handles Label10.Click

    End Sub
End Class

' Classe que representa os dados do formulário
Public Class DadosPropriedades
    Public Property Titulo As String
    Public Property Autor As String
    Public Property Responsavel As String
    Public Property Empresa As String
    Public Property Projetista As String
    Public Property Engenheiro As String
    Public Property Fornecedor As String
    Public Property WebLink As String
    Public Property Assunto As String
    Public Property DataCriacao As Date
End Class
