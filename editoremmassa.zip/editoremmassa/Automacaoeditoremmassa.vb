﻿Imports Inventor
Imports System.Runtime.InteropServices
Imports System.Windows.Forms

<ComVisible(True)>
Public Class Automacaoeditoremmassa

    Private ReadOnly _app As Inventor.Application

    Public Sub New(app As Inventor.Application)
        _app = app
    End Sub

    Public Sub Sincronizar()
        Try
            ' Instancia o controlador responsável pela lógica
            Dim controller As New EditorController(_app)
            controller.Executar()

        Catch ex As Exception
            MessageBox.Show("Erro na sincronização: " & ex.Message,
                            "Erro",
                            MessageBoxButtons.OK,
                            MessageBoxIcon.Error)
        End Try
    End Sub

End Class
